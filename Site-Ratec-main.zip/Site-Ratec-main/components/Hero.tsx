
import React from 'react';

const Hero: React.FC = () => {
  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      {/* Background Effects */}
      <div className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-fuchsia-500/10 rounded-full blur-[120px] -z-10 animate-pulse-glow"></div>
      <div className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] bg-purple-600/10 rounded-full blur-[100px] -z-10"></div>
      
      <div className="container mx-auto px-6 grid md:grid-cols-2 gap-12 items-center">
        <div className="space-y-8">
          <div className="inline-block px-4 py-1 rounded-full border border-fuchsia-500/30 bg-fuchsia-500/10 text-fuchsia-400 text-xs font-bold tracking-widest uppercase">
            Inovação que Transforma
          </div>
          <h1 className="font-orbitron text-5xl md:text-7xl font-bold leading-tight">
            Soluções Inteligentes para o <span className="text-fuchsia-500 neon-glow">Seu Negócio</span>
          </h1>
          <p className="text-xl text-slate-400 max-w-lg leading-relaxed">
            Especialistas em Inteligência Artificial, Automação e Desenvolvimento de Elite para empresas que buscam liderar o mercado.
          </p>
          <div className="flex flex-wrap gap-4">
            <button className="bg-gradient-to-r from-fuchsia-500 to-purple-600 hover:from-fuchsia-400 hover:to-purple-500 text-white font-bold py-4 px-8 rounded-lg shadow-[0_0_30px_rgba(217,70,239,0.3)] transition-all transform hover:-translate-y-1">
              Nossos Projetos
            </button>
            <button className="border border-fuchsia-500/30 hover:border-fuchsia-500/60 bg-white/5 py-4 px-8 rounded-lg transition-all backdrop-blur-sm">
              Nossas Soluções
            </button>
          </div>
        </div>

        <div className="relative">
          <div className="relative z-10 rounded-2xl overflow-hidden border border-fuchsia-500/20 shadow-[0_0_50px_rgba(217,70,239,0.15)] group">
            <img 
              src="https://picsum.photos/seed/ratec-tech/800/1000" 
              alt="RATEC Tecnologia" 
              className="w-full grayscale hover:grayscale-0 transition-all duration-700 transform group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent opacity-60"></div>
            
            {/* UI Overlay elements to look like Tech HUD */}
            <div className="absolute top-8 right-8 w-24 h-24 border-t-2 border-r-2 border-fuchsia-400/50 rounded-tr-xl"></div>
            <div className="absolute bottom-8 left-8 w-24 h-24 border-b-2 border-l-2 border-fuchsia-400/50 rounded-bl-xl"></div>
            
            <div className="absolute top-1/2 left-4 -translate-y-1/2 space-y-4 hidden md:block">
              <div className="w-1 h-12 bg-gradient-to-b from-fuchsia-400 to-transparent"></div>
              <div className="w-1 h-4 bg-fuchsia-400"></div>
              <div className="w-1 h-20 bg-gradient-to-t from-fuchsia-400 to-transparent"></div>
            </div>
          </div>
          
          {/* Floating UI Badges */}
          <div className="absolute -top-4 -right-4 md:right-10 bg-glass border border-fuchsia-500/30 p-4 rounded-xl backdrop-blur-md shadow-xl animate-bounce">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-fuchsia-500/20 flex items-center justify-center text-fuchsia-400">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <div>
                <p className="text-[10px] text-fuchsia-400 font-bold uppercase tracking-tighter">Eficiência</p>
                <p className="text-sm font-bold">+300% Produtividade</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
