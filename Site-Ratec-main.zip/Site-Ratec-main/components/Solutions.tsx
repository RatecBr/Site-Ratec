
import React from 'react';

const solutions = [
  {
    title: 'Inteligência Artificial',
    description: 'Implementação de LLMs e agentes inteligentes para automatizar processos e melhorar a tomada de decisão.',
    icon: (
      <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M13 10V3L4 14h7v7l9-11h-7z" />
      </svg>
    ),
    color: 'from-fuchsia-500 to-purple-600'
  },
  {
    title: 'Automação de Processos',
    description: 'Sistemas inteligentes que trabalham por você, eliminando tarefas repetitivas e aumentando a escala do seu negócio.',
    icon: (
      <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
      </svg>
    ),
    color: 'from-purple-600 to-pink-500'
  },
  {
    title: 'Desenvolvimento Web Elite',
    description: 'Aplicações web de alta performance com as tecnologias mais modernas do mercado, focadas em UX e conversão.',
    icon: (
      <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
      </svg>
    ),
    color: 'from-pink-500 to-fuchsia-500'
  }
];

const Solutions: React.FC = () => {
  return (
    <section id="solucoes" className="py-24 relative">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="font-orbitron text-4xl font-bold mb-4">Nossas <span className="text-fuchsia-500">Soluções</span></h2>
          <p className="text-slate-400 max-w-2xl mx-auto">Tecnologia de ponta para transformar a maneira como sua empresa opera no mundo digital.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {solutions.map((sol, idx) => (
            <div key={idx} className="group relative bg-glass border border-fuchsia-500/20 p-8 rounded-2xl transition-all hover:border-fuchsia-500/50 hover:-translate-y-2 overflow-hidden">
              <div className={`absolute -right-12 -top-12 w-32 h-32 bg-gradient-to-br ${sol.color} opacity-10 blur-2xl group-hover:opacity-30 transition-all`}></div>
              
              <div className={`w-16 h-16 rounded-xl bg-gradient-to-br ${sol.color} flex items-center justify-center text-white mb-6 shadow-lg shadow-fuchsia-500/20`}>
                {sol.icon}
              </div>
              
              <h3 className="font-orbitron text-xl font-bold mb-4 group-hover:text-fuchsia-400 transition-colors">{sol.title}</h3>
              <p className="text-slate-400 leading-relaxed text-sm">
                {sol.description}
              </p>
              
              <div className="mt-8 pt-6 border-t border-slate-800 flex items-center gap-2 text-fuchsia-400 text-xs font-bold uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-all">
                Saber Mais 
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                </svg>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Solutions;
