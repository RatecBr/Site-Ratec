
import React from 'react';

const projects = [
  {
    title: 'Sistema de Automação IA - Fintech',
    category: 'Inteligência Artificial',
    image: 'https://picsum.photos/seed/ratec-ai/600/800',
  },
  {
    title: 'Plataforma E-commerce de Elite',
    category: 'Desenvolvimento Web',
    image: 'https://picsum.photos/seed/ratec-web/600/800',
  },
  {
    title: 'Dashboard de Dados em Tempo Real',
    category: 'Data Analytics',
    image: 'https://picsum.photos/seed/ratec-data/600/800',
  },
  {
    title: 'Agente de Atendimento Inteligente',
    category: 'Automação',
    image: 'https://picsum.photos/seed/ratec-bot/600/800',
  }
];

const Portfolio: React.FC = () => {
  return (
    <section id="portfolio" className="py-24 bg-slate-950">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <h2 className="font-orbitron text-4xl font-bold mb-4">Projetos em <span className="text-fuchsia-500">Destaque</span></h2>
            <p className="text-slate-400 max-w-xl">Uma seleção de soluções inteligentes que entregamos para empresas que buscam excelência tecnológica.</p>
          </div>
          <div className="flex gap-4">
            <button className="text-sm font-bold border-b-2 border-fuchsia-500 pb-1 text-fuchsia-400">Todos</button>
            <button className="text-sm font-bold text-slate-500 hover:text-slate-300 transition-colors pb-1">IA</button>
            <button className="text-sm font-bold text-slate-500 hover:text-slate-300 transition-colors pb-1">Web</button>
          </div>
        </div>

        <div className="grid md:grid-cols-4 gap-6">
          {projects.map((project, idx) => (
            <div key={idx} className="group relative overflow-hidden rounded-2xl border border-fuchsia-500/10 hover:border-fuchsia-400/50 transition-all duration-500">
              <div className="aspect-[3/4] overflow-hidden">
                <img 
                  src={project.image} 
                  alt={project.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-6">
                <p className="text-fuchsia-400 text-[10px] font-bold uppercase tracking-widest mb-1">{project.category}</p>
                <h3 className="font-orbitron font-bold text-sm leading-tight text-white mb-4">{project.title}</h3>
                <button className="w-full py-2 bg-white/10 hover:bg-white/20 backdrop-blur-md rounded-lg text-xs font-bold transition-all border border-white/10">
                  Ver Detalhes
                </button>
              </div>
              
              {/* Floating Icon */}
              <div className="absolute top-4 right-4 w-8 h-8 rounded-full bg-fuchsia-500/20 backdrop-blur-md border border-fuchsia-500/30 flex items-center justify-center text-fuchsia-400 opacity-0 group-hover:opacity-100 transition-opacity">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-16 text-center">
          <button className="px-10 py-4 rounded-full border border-fuchsia-500/30 text-fuchsia-400 font-bold text-sm hover:bg-fuchsia-500/10 transition-all tracking-widest uppercase">
            Explorar Portfólio Completo
          </button>
        </div>
      </div>
    </section>
  );
};

export default Portfolio;
