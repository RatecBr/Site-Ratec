
import React from 'react';

const About: React.FC = () => {
  return (
    <section id="quem-somos" className="py-24 overflow-hidden">
      <div className="container mx-auto px-6 grid md:grid-cols-2 gap-16 items-center">
        <div className="relative">
          {/* Futuristic Graphic */}
          <div className="relative w-full aspect-square max-w-md mx-auto">
            <div className="absolute inset-0 border-2 border-fuchsia-500/10 rounded-full animate-[spin_20s_linear_infinite]"></div>
            <div className="absolute inset-4 border border-dashed border-fuchsia-500/20 rounded-full animate-[spin_15s_linear_infinite_reverse]"></div>
            <div className="absolute inset-8 bg-fuchsia-500/5 rounded-full blur-2xl"></div>
            
            <div className="absolute inset-0 flex items-center justify-center">
              <img 
                src="https://picsum.photos/seed/tech-core/600/600" 
                alt="Tech Core" 
                className="w-3/4 h-3/4 object-contain mix-blend-screen opacity-80"
              />
            </div>
            
            {/* Pulsing Dots */}
            <div className="absolute top-1/4 right-0 w-2 h-2 bg-fuchsia-400 rounded-full animate-ping"></div>
            <div className="absolute bottom-1/4 left-0 w-2 h-2 bg-purple-500 rounded-full animate-ping [animation-delay:-0.5s]"></div>
          </div>
        </div>

        <div className="space-y-6">
          <h2 className="font-orbitron text-4xl font-bold">Quem <span className="text-fuchsia-500">Somos</span></h2>
          <p className="text-slate-400 leading-relaxed">
            A RATEC é uma boutique de tecnologia especializada em soluções inteligentes que impulsionam o crescimento de negócios modernos. Nossa missão é simplificar a complexidade tecnológica através de IA e automação de elite. 
          </p>
          <p className="text-slate-400 leading-relaxed">
            Combinamos expertise técnica com visão estratégica para entregar resultados que não apenas resolvem problemas, mas criam novas oportunidades competitivas para nossos clientes.
          </p>
          
          <div className="grid grid-cols-2 gap-6 pt-8">
            <div className="p-4 bg-slate-900/50 border border-slate-800 rounded-xl">
              <h4 className="font-orbitron text-2xl font-bold text-fuchsia-400">10+</h4>
              <p className="text-xs text-slate-500 uppercase tracking-widest mt-1">Especialistas</p>
            </div>
            <div className="p-4 bg-slate-900/50 border border-slate-800 rounded-xl">
              <h4 className="font-orbitron text-2xl font-bold text-fuchsia-400">50+</h4>
              <p className="text-xs text-slate-500 uppercase tracking-widest mt-1">Empresas Atendidas</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
