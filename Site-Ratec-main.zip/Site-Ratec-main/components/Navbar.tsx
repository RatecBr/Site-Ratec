
import React, { useState, useEffect } from 'react';
import Logo from './Logo';

const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-glass border-b border-fuchsia-500/20 py-4' : 'bg-transparent py-6'}`}>
      <div className="container mx-auto px-6 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <Logo className="w-12 h-12" />
          <div className="flex flex-col">
            <span className="font-orbitron font-bold text-lg leading-none tracking-wider neon-glow">RATEC</span>
            <span className="font-orbitron text-[10px] leading-none tracking-[0.2em] text-fuchsia-400">SOLUÇÕES INTELIGENTES</span>
          </div>
        </div>

        <div className="hidden md:flex items-center gap-8 text-sm font-medium tracking-wide">
          <a href="#solucoes" className="hover:text-fuchsia-400 transition-colors">SOLUÇÕES</a>
          <a href="#portfolio" className="hover:text-fuchsia-400 transition-colors">PORTFÓLIO</a>
          <a href="#quem-somos" className="hover:text-fuchsia-400 transition-colors">QUEM SOMOS</a>
          <a href="#contato" className="hover:text-fuchsia-400 transition-colors">CONTATO</a>
          <button className="bg-gradient-to-r from-fuchsia-500 to-purple-600 hover:from-fuchsia-400 hover:to-purple-500 text-white font-bold py-2 px-6 rounded-full shadow-[0_0_20px_rgba(217,70,239,0.4)] transition-all transform hover:scale-105 active:scale-95">
            INICIAR
          </button>
        </div>

        <button className="md:hidden text-fuchsia-400">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16m-7 6h7" />
          </svg>
        </button>
      </div>
    </nav>
  );
};

export default Navbar;
