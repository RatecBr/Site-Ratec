
import React from 'react';
import Logo from './Logo';

const Footer: React.FC = () => {
  return (
    <footer id="contato" className="py-20 border-t border-slate-900 bg-slate-950">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-4 gap-12 mb-16">
          <div className="col-span-1 md:col-span-2 space-y-6">
            <div className="flex items-center gap-3">
              <Logo className="w-10 h-10" />
              <div className="flex flex-col">
                <span className="font-orbitron font-bold text-lg leading-none tracking-wider text-white">RATEC</span>
                <span className="font-orbitron text-[10px] leading-none tracking-[0.2em] text-fuchsia-400">SOLUÇÕES INTELIGENTES</span>
              </div>
            </div>
            <p className="text-slate-500 max-w-sm">
              Liderando a transformação digital com inteligência. Criamos o futuro dos negócios através de IA, Automação e Desenvolvimento de Elite.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 rounded-full bg-slate-900 flex items-center justify-center hover:bg-fuchsia-500 hover:text-white transition-all">
                <i className="fab fa-instagram"></i>
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-slate-900 flex items-center justify-center hover:bg-fuchsia-500 hover:text-white transition-all">
                <i className="fab fa-facebook"></i>
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-slate-900 flex items-center justify-center hover:bg-fuchsia-500 hover:text-white transition-all">
                <i className="fab fa-linkedin"></i>
              </a>
            </div>
          </div>

          <div>
            <h4 className="font-orbitron text-sm font-bold text-white mb-6 uppercase tracking-widest">Links</h4>
            <ul className="space-y-4 text-slate-500 text-sm">
              <li><a href="#solucoes" className="hover:text-fuchsia-400 transition-colors">Soluções</a></li>
              <li><a href="#portfolio" className="hover:text-fuchsia-400 transition-colors">Portfólio</a></li>
              <li><a href="#quem-somos" className="hover:text-fuchsia-400 transition-colors">Quem Somos</a></li>
              <li><a href="#contato" className="hover:text-fuchsia-400 transition-colors">Contato</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-orbitron text-sm font-bold text-white mb-6 uppercase tracking-widest">Contato</h4>
            <ul className="space-y-4 text-slate-500 text-sm">
              <li>contato@ratec.com.br</li>
              <li>+55 (11) 99999-9999</li>
              <li>Brasil</li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-slate-900 flex flex-col md:flex-row justify-between items-center gap-4 text-slate-600 text-xs">
          <p>© 2024 RATEC - Soluções Inteligentes. Todos os direitos reservados.</p>
          <div className="flex gap-6">
            <a href="#" className="hover:text-slate-400 transition-colors">Política de Privacidade</a>
            <a href="#" className="hover:text-slate-400 transition-colors">Termos de Uso</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
